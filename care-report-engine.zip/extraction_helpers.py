# OPTIONAL LEGACY EPX/VALOR EXTRACTORS. Not a reconciliation engine.
# Review extracted values against original sources; cents tolerances here are NOT final acceptance.
"""Local statement + transaction-file report generator. No network services."""
from __future__ import annotations
import argparse, calendar, csv, json, re
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from xml.sax.saxutils import escape
from pypdf import PdfReader
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.colors import Color, white
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase.pdfmetrics import stringWidth

ROOT=Path(__file__).resolve().parent
D=Decimal
ZERO=D('0')
class InputError(ValueError): pass
def money(value):
    s=str(value if value is not None else '').strip().replace('$','').replace(',','')
    if not s: return ZERO
    if s.startswith('(') and s.endswith(')'): s='-'+s[1:-1]
    try:
        n=D(s)
        if not n.is_finite(): raise ValueError()
        return n
    except Exception: raise InputError(f'Invalid amount: {value!r}')
def cents(n): return n.quantize(D('.01'),rounding=ROUND_HALF_UP)
def cash(n): return f'${n:,.2f}'
def brand(s):
    names={'VISA':'Visa','MC':'Mastercard','MASTERCARD':'Mastercard','AX':'Amex','AMEX':'Amex','AMERICAN EXPRESS':'Amex','DIS':'Discover','DISCOVER':'Discover','DISCOVER NETWORK':'Discover'}
    return names.get(str(s).upper().strip(),str(s).strip())

def read_transactions(path):
    path=Path(path)
    if path.suffix.lower()=='.csv':
        with path.open(encoding='utf-8-sig',newline='') as f: raw=list(csv.reader(f))
    elif path.suffix.lower()=='.xlsx':
        from openpyxl import load_workbook
        wb=load_workbook(path,read_only=True,data_only=True)
        populated=[s for s in wb if s.max_row>1]
        if len(populated)!=1: raise InputError('Use an Excel file with one transaction sheet, or export that sheet as CSV.')
        raw=list(populated[0].values);wb.close()
    else: raise InputError('Upload CSV or .xlsx. Save older .xls files as .xlsx first.')
    required=['STATUS','TRANSACTION DATE AND TIME','TXN TYPE','CARD SCHEME','BASE AMOUNT($)','NET AMOUNT($)']
    header_at=next((i for i,r in enumerate(raw[:20]) if 'STATUS' in [str(v or '').strip().upper() for v in r]),None)
    if header_at is None: raise InputError('Transaction header row was not found.')
    headers=[str(v or '').strip().upper() for v in raw[header_at]]
    if not set(required)<=set(headers): raise InputError('Missing transaction columns: '+', '.join(set(required)-set(headers)))
    # Resolve by header name, including Custom Fee in Excel columns X or Y.
    fee_columns=[i for i,h in enumerate(headers) if re.sub(r'[^A-Z]', '', h) in ('DIFFERENTIAL','CUSTOMFEE')]
    if not fee_columns: raise InputError('Missing transaction column: DIFFERENTIAL or CUSTOM FEE')
    result=[]
    for line,values in enumerate(raw[header_at+1:],header_at+2):
        if not any(v is not None and str(v).strip() for v in values): continue
        r=dict(zip(headers,values))
        fees=[money(values[i]) for i in fee_columns if i<len(values) and values[i] is not None and str(values[i]).strip()]
        if len(set(fees))>1: raise InputError(f'Differential and Custom Fee disagree on row {line}.')
        adjustment=fees[0] if fees else ZERO
        stamp=r['TRANSACTION DATE AND TIME']
        try: day=stamp.date() if isinstance(stamp,datetime) else stamp if isinstance(stamp,date) else datetime.strptime(str(stamp).split()[0],'%m/%d/%y').date()
        except Exception: raise InputError(f'Cannot read transaction date on row {line}.')
        status=str(r['STATUS']).strip().upper();kind=str(r['TXN TYPE']).strip().upper()
        result.append({'date':day,'status':status,'kind':kind,'brand':brand(r['CARD SCHEME']), 'base':money(r['BASE AMOUNT($)']), 'adjustment':adjustment, 'net':money(r['NET AMOUNT($)']), 'store':str(r.get('STORE NAME','') or '').strip(), 'card':str(r.get('MASKEDCARD NO','') or '').strip(), 'batch':str(r.get('BATCH NO','') or '').strip(), 'approval':str(r.get('APPROVAL CODE','') or '').strip(), 'refunded_amount':money(r.get('REFUNDED AMOUNT')), 'refunded_count':money(r.get('REFUNDED COUNT'))})
    if not result: raise InputError('No transactions found.')
    return result

def parse_epx(path):
    pages=[p.extract_text() or '' for p in PdfReader(path).pages]
    text='\n'.join(pages)
    if 'Deposit Detail Summary' not in text or 'Interchange Detail' not in text:
        raise InputError('This statement format needs review in Codex. The automatic reader supports the EPX format used for your approved report; scanned PDFs need text extraction first.')
    first=pages[0]
    period=re.search(r'(\d{2}/\d{2}/\d{2})\s*-\s*(\d{2}/\d{2}/\d{2})',text)
    if not period: raise InputError('Statement period was not found.')
    start,end=[datetime.strptime(s,'%m/%d/%y').date() for s in period.groups()]
    if start.month!=end.month or start.year!=end.year: raise InputError('Statement must cover a single calendar month.')
    lines=[s.strip() for s in first.splitlines() if s.strip()]
    month_label=start.strftime('%B %Y')
    try:
        idx=lines.index(month_label)
        identity=lines[idx+1:lines.index('Merchant Number:',idx)]
    except ValueError: raise InputError('Merchant name and address could not be read reliably.')
    if not 2<=len(identity)<=5: raise InputError('Merchant address needs review.')
    name=identity[0];address=identity[1:]
    mid_match=re.search(r'Merchant #:\s*(\d+)',text)
    mid=mid_match[1] if mid_match else ''
    summary=text.split('Deposit Detail Summary',1)[1].split('Billing Detail (Interchange)',1)[0]
    summary_rows=re.findall(r'Merchant Deposit (VISA|MC|Dis|AX)\s+(\d+)\s+([\d,.]+)\s+(\d+)\s+(\(?[\d,.]+\)?)\s+(\d+)\s+([\d,.]+)',summary)
    volumes=[]
    for code,count,vol,rc,refund,nc,net in summary_rows:
        volumes.append({'brand':brand(code),'count':int(count),'sales':money(vol),'refund_count':int(rc),'refunds':abs(money(refund)),'net':money(net)})
    if not volumes or len({v['brand'] for v in volumes})!=len(volumes): raise InputError('Card-brand summary is missing or duplicated.')
    bill=re.search(r'Billing\s+0\s+0\.00\s+0\s+(\(?[\d,.]+\)?)',summary)
    if not bill: raise InputError('Total statement fees could not be identified.')
    fees=abs(money(bill[1]))
    section=text.split('Interchange Detail',1)[1].split('Deposit Currency Summary',1)[0]
    services=[]
    for match in re.finditer(r'(Visa|Discover|MasterCard) Program.*?\n(.*?)(?=Total Discount)',section,re.S):
        b=brand(match[1]);entries=re.findall(r'US (.*?)\s+(\d+)\s+([\d,.]+)\s+([\d.]+) \+ ([\d.]+)%\s+([\d,.]+)',match[2])
        for kind in ['Debit','Credit']:
            selected=[r for r in entries if ('Check' in r[0])==(kind=='Debit')]
            if not selected: continue
            rates={money(r[4])/100 for r in selected};per_items={money(r[3]) for r in selected}
            services.append({'name':b+' '+kind+' Discount','brand':b,'kind':kind,'sales':sum(money(r[2]) for r in selected),'count':sum(int(r[1]) for r in selected),'rate':next(iter(rates)) if len(rates)==1 else None,'per_item':next(iter(per_items)) if len(per_items)==1 else None,'fee':sum(money(r[5]) for r in selected)})
    charges=text.split('Billing Detail (Charges)',1)[1].split('Interchange Detail',1)[0]
    amex=re.findall(r'Amex [^\n]*?\s+(\d+) @ ([\d,.]+) ([\d.]+)% \(([\d,.]+)\)',charges)
    if amex:
        rates={money(r[2])/100 for r in amex}
        services.append({'name':'Amex Credit Discount','brand':'Amex','kind':'Credit','sales':sum(money(r[1]) for r in amex),'count':sum(int(r[0]) for r in amex),'rate':next(iter(rates)) if len(rates)==1 else None,'per_item':ZERO,'fee':sum(money(r[3]) for r in amex)})
    monthly_match=re.search(r'Monthly Basic Service Fee\s+(\d+)\s+([\d.]+)\s+\(([\d,.]+)\)',charges)
    monthly=abs(money(monthly_match[3])) if monthly_match else ZERO
    if monthly_match: services.append({'name':'Monthly Service Fee','brand':'','kind':'Monthly','sales':monthly,'count':int(monthly_match[1]),'rate':ZERO,'per_item':money(monthly_match[2]),'fee':monthly})
    known=sum(s['fee'] for s in services)
    if known>fees+D('.02'): raise InputError('Parsed service fees exceed the statement total.')
    if fees-known>D('.02'):
        services.append({'name':'Other statement charges','brand':'','kind':'Other','sales':ZERO,'count':0,'rate':None,'per_item':None,'fee':fees-known})
    d={'merchant':name,'address':address,'merchant_id':mid,'start':start,'end':end,'volumes':volumes,'services':services,'fees':fees}
    validate_statement(d)
    return d

def validate_statement(d):
    if not d['merchant'] or not d['address']: raise InputError('Merchant name/address required from statement.')
    if len(d['volumes'])>4: raise InputError('More than four card brands need a layout review.')
    for v in d['volumes']:
        if abs(v['sales']-v['refunds']-v['net'])>D('.02'): raise InputError('Statement sales/refunds do not reconcile for '+v['brand'])
        rows=[s for s in d['services'] if s['brand']==v['brand']]
        if abs(sum(s['sales'] for s in rows)-v['sales'])>D('.02') or sum(s['count'] for s in rows)!=v['count']:
            raise InputError('Statement rate detail does not reconcile for '+v['brand'])
    if abs(sum(s['fee'] for s in d['services'])-d['fees'])>D('.02'): raise InputError('Statement fee total does not reconcile.')
    if sum(v['net'] for v in d['volumes'])<=0: raise InputError('Positive net sales required for an effective rate.')

