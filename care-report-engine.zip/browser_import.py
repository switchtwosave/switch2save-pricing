"""Local EPX/Valor importer. Ambiguities produce an audit, never a final report."""
from pathlib import Path
from datetime import datetime,date
from decimal import Decimal as D
from collections import defaultdict
import calendar,csv,hashlib,io,json,re,zipfile
from pypdf import PdfReader
from calculations import calculate
from generate_report import render
from statement_address import read_statement_address
from extraction_helpers import parse_epx as legacy_parse

VERSION='1.1.1-browser'
ZERO=D(0)
AMT=r'\(?-?[\d,]+\.\d{2}\)?'
BRANDS={'VISA':'Visa','MC':'Mastercard','MASTERCARD':'Mastercard','AX':'Amex','AMEX':'Amex','AMERICAN EXPRESS':'Amex','DIS':'Discover','DISCOVER':'Discover'}
class ReviewNeeded(ValueError):pass
def need(ok,why):
 if not ok:raise ReviewNeeded(why)
def number(v,blank=False,cents=True):
 s=str(v if v is not None else '').strip().replace('$','').replace(',','')
 if not s and blank:return ZERO
 need(bool(s),'A required amount is blank. No zero was substituted.')
 if s.startswith('(') and s.endswith(')'):s='-'+s[1:-1]
 try:n=D(s)
 except Exception:raise ReviewNeeded('Unreadable numeric field.') from None
 need(n.is_finite(),'Nonfinite numeric field.')
 need(not cents or n==n.quantize(D('.01')),'Source amount has fractions of a cent.')
 return n
def brand(v):
 b=BRANDS.get(str(v).strip().upper());need(b is not None,'Unsupported card brand.');return b
def norm(v):return ' '.join(str(v or '').split()).casefold()
def day(v):
 if isinstance(v,datetime):return v.date()
 if isinstance(v,date):return v
 s=str(v or '').strip().split()[0] if str(v or '').strip() else ''
 for fmt in ('%m/%d/%y','%m/%d/%Y','%Y-%m-%d'):
  try:return datetime.strptime(s,fmt).date()
  except ValueError:pass
 raise ReviewNeeded('Unreadable date; use MM/DD/YY, MM/DD/YYYY or YYYY-MM-DD.')
def serialize(v):
 if isinstance(v,(D,date)):return str(v)
 raise TypeError(type(v).__name__)
def source(p):return {'name':Path(p).name,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}

def parse_statement(path,audit):
 reader=PdfReader(path)
 # Payments Hub PDFs carry an owner-only lock with an empty open password; those read normally.
 need(not reader.is_encrypted or reader.decrypt(''),'Password-protected statements are unsupported. Supply an unlocked original PDF.')
 need(0<len(reader.pages)<=100,'Statement must contain 1 to 100 pages.')
 text='\n'.join(p.extract_text() or '' for p in reader.pages)
 need('Deposit Detail Summary' in text and 'Interchange Detail' in text,'Unsupported statement. Use a text-based EPX PDF with deposit and interchange detail. Scans need OCR; no external upload was used.')
 st=legacy_parse(path)
 st['start']=str(st['start']);st['end']=str(st['end'])
 start,end=day(st['start']),day(st['end'])
 need(start.day==1 and end.day==calendar.monthrange(start.year,start.month)[1],'Only complete single-month EPX statements are supported.')
 periods=set(re.findall(r'(\d{2}/\d{2}/\d{2})\s*-\s*(\d{2}/\d{2}/\d{2})',text))
 need(len(periods)==1,'Statement period is inconsistent across pages.')
 mids=set(re.findall(r'Merchant #:\s*(\S+)',text));need(mids=={st['merchant_id']},'Statement MID differs across pages.')
 address=read_statement_address(path,st);st['address']=address['address'];audit['address_source']=address
 need(len(st['address'])<=3,'Address needs more space than the approved header. No address line was dropped.')
 summary=text.split('Deposit Detail Summary',1)[1].split('Billing Detail (Interchange)',1)[0]
 totals=re.findall(rf'Period Total:\s+(\d+)\s+({AMT})\s+(\d+)\s+({AMT})\s+(\d+)\s+({AMT})\s+({AMT})',summary)
 need(len(totals)==1,'Period-total Released to account is missing or ambiguous.')
 t=totals[0];released=number(t[-1]);G=sum(v['sales'] for v in st['volumes']);R=sum(v['refunds'] for v in st['volumes'])
 need(number(t[-2])==released,'Net and released deposit differ; funding adjustments need review.')
 need(number(t[1])==G and int(t[0])==sum(v['count'] for v in st['volumes']) and int(t[2])==sum(v['refund_count'] for v in st['volumes']),'Period counts/volumes differ from brand summaries.')
 need(G-R-st['fees']==released,'Released funds differ from net sales minus actual fees. Reserve/funding adjustments need explicit review; no amount was invented.')
 cover=re.findall(rf'Total deposits to all your accounts for this period are:\s*({AMT})',text)
 need(cover and all(number(v)==released for v in cover),'Cover and period released-to-account totals differ or are missing.')
 st.update(released_to_account=released,deposit_adjustments=ZERO,released_source='Deposit Detail Summary > Period Total > Release to Accounts, matched to cover total')
 # Replace legacy residual Other charges with individually identified source rows.
 st['services']=[s for s in st['services'] if s['kind']!='Other']
 charges=text.split('Billing Detail (Charges)',1)[1].split('Interchange Detail',1)[0]
 for label,count,rate,fee in re.findall(r'Processor Fee - (.+?)\s+(\d+)\s+([\d.]+)\s+\(([\d,.]+)\)',charges):
  if label!='Monthly Basic Service Fee':st['services'].append(dict(name=label,brand='',kind='Other',sales=ZERO,count=int(count),rate=None,per_item=number(rate,cents=False),fee=number(fee)))
 need(sum(s['fee'] for s in st['services'])==st['fees'],'Actual fee rows do not sum exactly to statement fees. An unrecognized charge needs review; no residual fee was fabricated.')
 need(len(st['services'])<=9,'More than nine service rows require a layout extension.')
 section=text.split('Deposit Detail\n',1)[1].split('Deposit Detail Summary',1)[0] if 'Deposit Detail\n' in text else ''
 daily=[]
 for stamp,b,n,v,nr,r in re.findall(rf'(\d{{2}}/\d{{2}})\s*Merchant Deposit (VISA|MC|Dis|AX)\s+(\d+)\s+({AMT})\s+(\d+)\s+({AMT})',section):
  dt=day(stamp+'/'+str(start.year));need(start<=dt<=end,'Deposit day outside statement period.')
  daily.append(dict(date=dt,brand=brand(b),count=int(n),sales=number(v),refund_count=int(nr),refunds=abs(number(r))))
 need(daily and len({(x['date'],x['brand']) for x in daily})==len(daily),'Daily deposit rows are missing or duplicated; settlement review required.')
 for v in st['volumes']:
  ds=[d for d in daily if d['brand']==v['brand']]
  need(all(sum(x[k] for x in ds)==v[k] for k in ('count','sales','refund_count','refunds')),'Daily deposits do not sum exactly to '+v['brand']+' totals.')
 audit['statement_checks']={'cover_identity':True,'period_deposit':True,'actual_fee_total':True,'daily_brand_groups':len(daily)}
 return st,daily

def read_transactions(path,audit):
 path=Path(path)
 if path.suffix.lower()=='.csv':
  try:raw=list(csv.reader(io.StringIO(path.read_text(encoding='utf-8-sig')),strict=True))
  except (UnicodeError,csv.Error):raise ReviewNeeded('CSV must be a valid UTF-8 Valor export.') from None
 elif path.suffix.lower()=='.xlsx':
  from openpyxl import load_workbook
  with zipfile.ZipFile(path) as z:need(sum(x.file_size for x in z.infolist())<100_000_000,'Expanded workbook exceeds 100 MB.')
  wb=load_workbook(path,read_only=True,data_only=False);sheets=[s for s in wb if s.max_row>1]
  need(len(sheets)==1,'XLSX must contain one populated transaction sheet; otherwise export the desired sheet as CSV.')
  need(sheets[0].max_row<=50020 and sheets[0].max_column<=200,'Workbook exceeds 50,000 rows / 200 columns.')
  raw=list(sheets[0].values);wb.close()
 else:raise ReviewNeeded('Use a Valor .csv or .xlsx export. Older .xls files are unsupported.')
 at=next((i for i,r in enumerate(raw[:20]) if 'STATUS' in [str(v or '').strip().upper() for v in r]),None)
 need(at is not None,'Valor header row missing from first 20 rows.')
 headers=[str(v or '').strip().upper() for v in raw[at]];named=[h for h in headers if h]
 need(len(named)==len(set(named)),'Duplicate transaction column names need review.')
 required={'STATUS','TRANSACTION DATE AND TIME','TXN TYPE','CARD SCHEME','BASE AMOUNT($)','NET AMOUNT($)'}
 need(required<=set(headers),'Missing Valor columns: '+', '.join(sorted(required-set(headers))))
 fee_cols=[h for h in headers if re.sub(r'[^A-Z]','',h) in ('DIFFERENTIAL','CUSTOMFEE')]
 need(fee_cols,'Missing Differential / Custom Fee surcharge column.')
 rows=[];seen=set()
 for line,values in enumerate(raw[at+1:],at+2):
  if not any(v is not None and str(v).strip() for v in values):continue
  need(len(rows)<50000,'More than 50,000 transaction rows.')
  r=dict(zip(headers,values));status=str(r.get('STATUS','')).strip().upper();kind=str(r.get('TXN TYPE','')).strip().upper()
  void=any(str(r.get(k,'')).strip().upper() in ('TRUE','YES','Y','1','VOID','VOIDED','CANCELLED','CANCELED') for k in ('VOID','VOIDED','IS VOID','IS VOIDED','CANCELLED'))
  reason='cash' if 'CASH' in kind else 'void/cancelled' if void or any(x in kind for x in ('VOID','CANCEL')) or status in ('VOID','VOIDED','CANCELLED','CANCELED') else 'declined' if status in ('DECLINED','DECLINE','FAILED') else None
  if reason:audit['row_dispositions'].append(dict(row=line,disposition='excluded',reason=reason));continue
  need(status=='APPROVED',f'Row {line}: unknown or blank status.')
  need(kind in {'CREDIT SALE','SIGN/DEBIT SALE','DEBIT SALE','CREDIT REFUND','SIGN/DEBIT REFUND','DEBIT REFUND'},f'Row {line}: unsupported transaction type.')
  # STORE NAME is optional (current Valor exports omit it); when present it must be filled.
  store=str(r.get('STORE NAME','') or '').strip();need(store or 'STORE NAME' not in headers,f'Row {line}: missing merchant name.')
  fees=[number(r[h]) for h in fee_cols if r.get(h) is not None and str(r[h]).strip()]
  need(fees,f'Row {line}: surcharge field blank; use an explicit zero when none was charged.')
  need(len(set(fees))==1,f'Row {line}: Differential and Custom Fee disagree.')
  amount=number(r.get('NET AMOUNT($)'));base=number(r.get('BASE AMOUNT($)'));fee=fees[0];sale=kind.endswith('SALE');typ='Credit' if kind.startswith('CREDIT') else 'Debit'
  need(base+fee==amount,f'Row {line}: base plus surcharge differs from net.')
  need((amount>0 and base>=0 and fee>=0) if sale else (amount<0 and base<=0 and fee<=0),f'Row {line}: unexpected signs or zero-net reversal require review.')
  need(typ!='Debit' or fee==0,f'Row {line}: debit surcharge requires investigation.')
  sid=next((str(r[h]).strip() for h in ('TRANSACTION ID','TXN ID','TXN ID#','TRANSACTION ID#') if r.get(h) is not None and str(r[h]).strip()),'')
  if sid:need(sid not in seen,f'Row {line}: duplicate transaction ID. Resolve overlapping exports.');seen.add(sid)
  settlement=next((day(r[h]) for h in ('SETTLEMENT DATE','DEPOSIT DATE') if r.get(h) is not None and str(r[h]).strip()),None)
  rows.append(dict(row=line,id='row-'+str(line),source_id=sid,original_id=str(r.get('ORIGINAL TRANSACTION ID','') or '').strip(),date=day(r.get('TRANSACTION DATE AND TIME')),settlement=settlement,store=store,mid=str(r.get('MID',r.get('MERCHANT ID','')) or '').strip(),brand=brand(r.get('CARD SCHEME')),kind=typ,sale=sale,amount=amount,base=base,surcharge=fee,card=str(r.get('MASKEDCARD NO',r.get('MASKED CARD NO','')) or '').strip(),batch=str(r.get('BATCH NO','') or '').strip(),approval=str(r.get('APPROVAL CODE','') or '').strip(),refunded_amount=abs(number(r.get('REFUNDED AMOUNT'),True)),refunded_count=number(r.get('REFUNDED COUNT'),True)))
 need(rows,'No approved card transactions were found.')
 return rows

def stats(rows):
 ss=[r for r in rows if r['sale']];rr=[r for r in rows if not r['sale']]
 return len(ss),sum((r['amount'] for r in ss),ZERO),len(rr),sum((-r['amount'] for r in rr),ZERO)
def wanted(d):return d['count'],d['sales'],d['refund_count'],d['refunds']

def reconcile(rows,st,daily,audit):
 need(not any(r['store'] for r in rows) or {norm(r['store']) for r in rows}=={norm(st['merchant'])},'Store name differs from statement merchant, or export includes multiple merchants. DBA/legal-name differences need review.')
 need(all(not r['mid'] or r['mid']==st['merchant_id'] for r in rows),'Transaction MID differs from statement.')
 need(len({bool(r['settlement']) for r in rows})==1,'Settlement dates are filled on only some rows. Supply a consistent export.')
 grouped=defaultdict(list)
 for r in rows:grouped[(r['settlement'] or r['date'],r['brand'],bool(r['settlement']))].append(r)
 used=set();selected=[];mappings=[];discrepancies=[];reversed_ids=set()
 for target in sorted(daily,key=lambda x:(x['date'],x['brand'])):
  if wanted(target)==(0,ZERO,0,ZERO):continue
  candidates=[]
  for key,group in grouped.items():
   dt,b,explicit=key
   if b!=target['brand'] or (dt!=target['date'] if explicit else not 0<=(target['date']-dt).days<=7):continue
   if stats(group)==wanted(target):candidates.append((key,group,[]))
   else:
    pairs=[];consumed=set();possible=[]
    for refund in (r for r in group if not r['sale']):
     hits=[s for s in group if s['sale'] and s['kind']==refund['kind'] and s['date']==refund['date'] and s['amount']==-refund['amount'] and s['refunded_amount']==s['amount'] and s['refunded_count']==1 and all(s[k] and s[k]==refund[k] for k in ('card','batch','approval'))]
     if len(hits)==1:possible.append((hits[0],refund))
    for sale,refund in possible:
     # Identical refunds are not interchangeable evidence. Do not pick the first.
     if sum(s['id']==sale['id'] for s,r in possible)==1:
      consumed.update((sale['id'],refund['id']));pairs.append((sale,refund))
    remaining=[r for r in group if r['id'] not in consumed]
    if pairs and stats(remaining)==wanted(target):candidates.append((key,remaining,pairs))
  if len(candidates)!=1:
   discrepancies.append({'deposit_date':str(target['date']),'brand':target['brand'],'expected':wanted(target),'matching_export_groups':len(candidates),'reason':'missing exact daily match' if not candidates else 'ambiguous daily match'});continue
  key,group,pairs=candidates[0]
  if key in used:discrepancies.append({'deposit_date':str(target['date']),'brand':target['brand'],'reason':'export group matches multiple deposit days'});continue
  used.add(key);selected.extend(group)
  mappings.append({'deposit_date':str(target['date']),'transaction_date':str(key[0]),'brand':key[1],'method':'explicit settlement date' if key[2] else 'unique exact daily count/amount/refund match within seven days','rows':[r['row'] for r in group],'actual':stats(group),'expected':wanted(target)})
  for sale,refund in pairs:
   reversed_ids.add(sale['id'])
   for r in (sale,refund):audit['row_dispositions'].append(dict(row=r['row'],disposition='same-day full reversal excluded',matched_row=refund['row'] if r is sale else sale['row'],reason='same date/batch/card/approval, original metadata and exact statement daily totals'))
 audit['daily_matches']=mappings;audit['discrepancies']=discrepancies
 need(not discrepancies,'Daily settlement reconciliation needs review. Audit lists missing/ambiguous days. Include necessary adjacent-month transactions or settlement-date evidence; no fixed date shift was assumed.')
 start,end=day(st['start']),day(st['end'])
 for key,group in grouped.items():
  if key in used:continue
  if key[2] and not start<=key[0]<=end:reason='explicit settlement date outside statement period'
  elif key[0]<start:reason='prior-period original-sale evidence; no matching current deposit'
  elif key[0]>end:reason='transaction occurred after statement period'
  else:
   audit['discrepancies'].append({'rows':[r['row'] for r in group],'date':str(key[0]),'brand':key[1],'reason':'unassigned in-period group; needs settlement or reversal evidence'});continue
  for r in group:audit['row_dispositions'].append(dict(row=r['row'],disposition='outside selected deposits',reason=reason))
 need(not audit['discrepancies'],'Unassigned in-period transactions need boundary/reversal evidence. No final-day sales were silently discarded.')
 retained=[];refunds=[];allocations=defaultdict(lambda:[ZERO,ZERO])
 for r in selected:
  if r['sale']:retained.append(dict(id=r['id'],brand=r['brand'],kind=r['kind'],amount=str(r['amount']),surcharge=str(r['surcharge']),status='APPROVED',void=False,cash=False))
  else:
   returned=abs(r['surcharge']);basis='Explicit returned surcharge in source refund field.' if returned else ''
   candidates=[s for s in rows if s['sale'] and s['id'] not in reversed_ids and s['brand']==r['brand'] and s['kind']==r['kind'] and s['date']<=r['date'] and (r['date']-s['date']).days<=90 and s['amount']>=-r['amount'] and ((r['original_id'] and s['source_id']==r['original_id']) or (not r['original_id'] and r['card'] and s['card']==r['card'] and s['refunded_amount']>=-r['amount'] and s['refunded_count']>0))]
   if r['kind']=='Debit':returned=ZERO;basis='Debit refund, explicit zero surcharge and exact daily statement match.'
   elif not returned:
    need(len(candidates)==1,f'Refund row {r["row"]}: original sale missing/ambiguous. Zero Custom Fee alone cannot establish surcharge retention. Supply original-sale evidence, up to 90 days earlier.')
    s=candidates[0]
    if -r['amount']==s['amount']:returned=s['surcharge'];basis='Full original total refunded; original surcharge returned under confirmed policy.'
    elif -r['amount']<=s['base']:returned=ZERO;basis='Partial/base-only refund; surcharge retained under confirmed policy and no explicit return.'
    else:raise ReviewNeeded(f'Refund row {r["row"]}: amount between original base and total needs explicit surcharge allocation.')
   if len(candidates)==1:
    s=candidates[0];allocations[s['id']][0]+=-r['amount'];allocations[s['id']][1]+=returned
    need(allocations[s['id']][0]<=s['amount'] and allocations[s['id']][1]<=s['surcharge'],'Refunds exceed the matched original sale/surcharge. Possible duplicate refunds require review.')
    audit.setdefault('refund_matches',[]).append({'refund_row':r['row'],'original_row':s['row'],'returned_surcharge':str(returned),'basis':basis})
   refunds.append(dict(id=r['id'],brand=r['brand'],amount=str(-r['amount']),surcharge_returned=str(returned),match_basis=basis+' Matched daily statement count, cents and brand.'))
  audit['row_dispositions'].append(dict(row=r['row'],disposition='retained sale' if r['sale'] else 'settled refund'))
 return retained,refunds

def run(statement_path,transactions_path,comparison='0.03'):
 audit={'version':VERSION,'status':'needs review','sources':[],'row_dispositions':[],'discrepancies':[],
 'assumptions':{'comparison_rate':comparison,'comparison_is_assumed_benchmark':True,'annual_includes_monthly_fee':True,'effective_rate_excludes_monthly_fee':True,'refund_policy':'Partial/base-only refunds retain surcharge unless explicitly returned; full-total refunds return original surcharge. No proportional inference.','opportunity':'Not shown without separately established eligibility.','settlement':'Exact daily matching; no universal date shift.'}}
 try:
  for p in (statement_path,transactions_path):
   need(0<Path(p).stat().st_size<=20_000_000,'Each input must be nonempty and at most 20 MB.');audit['sources'].append(source(p))
  need(Path(statement_path).suffix.lower()=='.pdf','Statement must be an original EPX PDF.')
  st,daily=parse_statement(statement_path,audit);audit['merchant']=st['merchant'];audit['period']=st['start'][:7]
  rows=read_transactions(transactions_path,audit);sales,refunds=reconcile(rows,st,daily,audit)
  ids={s['id'] for s in sales};charged=[r for r in rows if r['id'] in ids and r['surcharge']>0]
  label='3%' if charged and all((r['base']*D('.03')).quantize(D('.01'),rounding='ROUND_HALF_UP')==r['surcharge'] for r in charged) else 'Actual'
  data=dict(version='1.0',statement=st,retained_sales=sales,settled_refunds=refunds,comparison_rate=str(number(comparison,cents=False)),surcharge_rate_label=label,opportunity={'show':False,'eligible_sale_ids':[],'condition':''},reconciliation={'verified':True,'unresolved':[],'evidence':'Complete row dispositions, unique daily matches, refund allocation and exact brand/service/funding checks in generated audit.','sources':audit['sources']})
  data=json.loads(json.dumps(data,default=serialize));result=calculate(data)
  need(result['a']['surcharge']>=0 and result['a']['net_fees']>=0,'Negative retained surcharge or processing cost needs a reviewed presentation.')
  from reportlab.pdfbase.pdfmetrics import stringWidth
  need(stringWidth(st['merchant'],'Helvetica-Bold',13)<=340,'Merchant name exceeds approved header width; no name was truncated.')
  output=Path(statement_path).parent/'care-report.pdf';result=render(data,output,statement_path)
  audit.update(status='reconciled',calculations=result,normalized_input=data)
  name=re.sub(r'[^A-Za-z0-9._-]+','-',st['merchant']).strip('-')+'-'+st['start'][:7]+'-Care-Savings-Report'
  return {'ok':True,'name':name,'pdf_path':str(output),'audit':json.dumps(audit,default=serialize,indent=2),'summary':{'merchant':st['merchant'],'period':result['period_label'],'net_processing':str(result['a']['net_fees']),'effective_rate':str(result['rate_display']),'annual_savings':str(result['annual']),'refunds':result['a']['refund_count'],'daily_groups':len(daily)}}
 except Exception as e:
  audit['message']=str(e)
  return {'ok':False,'message':str(e),'audit':json.dumps(audit,default=serialize,indent=2)}
