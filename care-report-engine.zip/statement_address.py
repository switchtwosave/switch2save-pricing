"""Read the merchant address from the original EPX statement at render time."""
from datetime import date
from pathlib import Path
import hashlib
import re
from pypdf import PdfReader


def read_statement_address(statement_path, expected):
    if statement_path is None:
        raise ValueError('Original merchant statement PDF is required to verify the address.')
    source = Path(statement_path)
    raw = source.read_bytes()
    reader = PdfReader(source)
    text = reader.pages[0].extract_text() if reader.pages else ''
    lines = [line.strip() for line in (text or '').splitlines() if line.strip()]
    period = date.fromisoformat(str(expected['start'])).strftime('%B %Y')
    if 'Merchant Statement' not in lines or lines.count(period) != 1:
        raise ValueError('Statement address needs review: unreadable or unsupported cover page, or wrong month.')
    start = lines.index(period) + 1
    try:
        end = lines.index('Merchant Number:', start)
    except ValueError:
        raise ValueError('Statement merchant address block could not be identified.') from None
    identity = lines[start:end]
    if not 3 <= len(identity) <= 5:
        raise ValueError('Statement address is incomplete or ambiguous; review the original page.')
    if ' '.join(identity[0].split()).casefold() != ' '.join(expected['merchant'].split()).casefold():
        raise ValueError('Statement merchant name does not match the report.')
    mids = set(re.findall(r'Merchant #:\s*(\S+)', text or ''))
    if mids != {str(expected['merchant_id'])}:
        raise ValueError('Statement MID does not match the report or cannot be verified.')
    address = identity[1:]
    return {
        'name': source.name,
        'sha256': hashlib.sha256(raw).hexdigest(),
        'page': 1,
        'merchant_id': str(expected['merchant_id']),
        'address': address,
        'input_address_replaced': expected.get('address') != address,
    }


def verify_report_address(report_path, address):
    lines = [line.strip() for page in PdfReader(report_path).pages
             for line in (page.extract_text() or '').splitlines() if line.strip()]
    if not any(lines[i:i + len(address)] == address for i in range(len(lines))):
        raise ValueError('Rendered report address does not match the original statement.')
