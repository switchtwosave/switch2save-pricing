"""Render the approved Care Payments report from reconciled JSON. No network access."""
from pathlib import Path
import argparse,json,hashlib
from decimal import Decimal as D
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.pdfbase.pdfmetrics import stringWidth
from calculations import calculate,cents
from statement_address import read_statement_address,verify_report_address

def rate_text(rate):
 if rate is None:return '-'
 value=format(rate*100,'f').rstrip('0').rstrip('.')
 if '.' not in value:value+='.'
 value=value.ljust(len(value.split('.')[0])+3,'0')
 return value+'%'

def render(data,out,statement_path=None):
 source_address=read_statement_address(statement_path,data['statement'])
 if len(source_address['address'])>3:
  raise ValueError('Statement address needs more header space; review the layout without dropping address lines.')
 data=dict(data,statement=dict(data['statement'],address=source_address['address']))
 result=calculate(data)
 result['address_source']=source_address
 st=result['st'];a=result['a'];base=result['base'];annual=result['annual'];tier=result['tier'];recovery_display=result['recovery_display'];without=result['without'];without_volume=result['without_volume'];possible_month=result['possible_month'];possible_year=result['possible_year'];period_label=result['period_label'];rate_display=result['rate_display']
 if len(st['volumes'])>4 or len(st['services'])>9:raise ValueError('Detail rows exceed approved one-page layout. Review required; do not omit fees.')
 root=Path(__file__).resolve().parent
 out=Path(out)
 out.parent.mkdir(parents=True,exist_ok=True)
 c=canvas.Canvas(str(out),pagesize=(612,792),invariant=1);c.setTitle(st['merchant']+' | '+period_label+' Savings Report')
 navy=HexColor('#182960');blue=HexColor('#3045FF');teal=HexColor('#3045FF');muted=HexColor('#596B77');pale=HexColor('#EEF1FF');line=HexColor('#D6E1E7');green=HexColor('#3045FF')
 def text(x,y,t,size=9,font='Helvetica',color=navy):
  limit=(232 if x==49 else 266 if x==81 else 588-x)
  if stringWidth(t,font,size)>limit: raise ValueError('Text exceeds approved layout; review required: '+t)
  c.setFillColor(color);c.setFont(font,size);c.drawString(x,792-y,t)
 def right(x,y,t,size=9,font='Helvetica',color=navy):
  c.setFillColor(color);c.setFont(font,size);c.drawRightString(x,792-y,t)
 def box(x,y,w,h,col):
  c.setFillColor(col);c.roundRect(x,792-y-h,w,h,8,fill=1,stroke=0)
 def rule(y,x=320,w=260):
  c.setStrokeColor(line);c.setLineWidth(.7);c.line(x,792-y,x+w,792-y)
 def money(v):return f'${v:,.2f}'
 c.drawImage(str(root/'assets/logo_center.png'),-7,792-86,width=200,height=77,preserveAspectRatio=True,mask='auto')
 right(580,36,st['merchant'],13,'Helvetica-Bold',HexColor('#182960'))
 right(580,51,period_label+' Savings Report',9,'Helvetica-Bold',teal)
 right(580,65,'MID '+st['merchant_id'],8,color=muted)
 for i,address_line in enumerate(st['address']):
  if stringWidth(address_line,'Helvetica',8)>340:
   raise ValueError('Statement address exceeds header width; review layout without truncating the address.')
  right(580,77+9*i,address_line,8,color=muted)
 c.translate(0,55)
 box(32,160,266,169,pale)
 # Vector diamond emblem
 def facet(points,fill):
  c.setFillColor(HexColor(fill));c.setStrokeColor(teal);c.setLineWidth(.7)
  path=c.beginPath();path.moveTo(points[0][0],792-points[0][1])
  for x,y in points[1:]:path.lineTo(x,792-y)
  path.close();c.drawPath(path,fill=1,stroke=1)
 facet([(43,186),(49,178),(55,186)],'#AAB5FF')
 facet([(49,178),(65,178),(59,186),(55,186)],'#FFFFFF')
 facet([(65,178),(71,186),(59,186)],'#7989FF')
 facet([(43,186),(55,186),(57,204)],'#5369FF')
 facet([(55,186),(59,186),(57,204)],'#DFE4FF')
 facet([(59,186),(71,186),(57,204)],'#3045FF')
 text(81,190,tier+' STATUS',13,'Helvetica-Bold')
 high_recovery=recovery_display
 verified_credit=[r for r in data['retained_sales'] if r['kind']=='Credit']
 text(49,239,f'{high_recovery}%',34,'Helvetica-Bold',teal)
 recovery_label_x=49+stringWidth(f'{high_recovery}%','Helvetica-Bold',34)+14
 text(recovery_label_x,224,'of credit processing',10)
 text(recovery_label_x,238,'fees recovered',10)
 rule(253,x=49,w=232)
 text(49,272,f"{a['credit_offset_count']} of {len(verified_credit)} credit sales surcharged",10,'Helvetica-Bold')
 text(49,289,f'{len(without)} without surcharge: {money(without_volume)}',10)
 if data['opportunity']['show']:
  text(49,309,f'Potential savings: {money(possible_month)}/mo | {money(possible_year)}/yr*',10,'Helvetica-Bold',teal)
  text(49,322,'*'+data['opportunity']['condition'],7,color=muted)
 
 red=HexColor('#ED0054')
 credit_sales=sum(v['sales'] for v in st['services'] if v['kind']=='Credit')
 debit_sales=sum(v['sales'] for v in st['services'] if v['kind']=='Debit')
 
 # Volume: remove refunds and collected surcharges to establish the rate base.
 box(310,157,278,99,HexColor('#EEF1FF'))
 text(320,171,'VOLUME',9,'Helvetica-Bold',teal)
 volume_rows=[
  (183,f"Total credit ({a['credit_count']})",credit_sales,navy,False),
  (195,f"Total debit ({a['debit_count']})",debit_sales,navy,False),
  (207,f"Total sales ({a['sales_count']})",a['gross_sales'],navy,False),
  (219,f"Refunds ({a['refund_count']})",a['refunds'],red,True),
  (231,f"Net sales (incl. {money(a['surcharge'])} surcharge)",a['net_sales'],navy,False),
  (247,'Statement net deposit',st['released_to_account'],navy,False)]
 for y,label,val,color,minus in volume_rows:
  text(320,y,label,8.5,'Helvetica-Bold' if y in (183,195,247) else 'Helvetica',color)
  right(580,y,('-' if minus and val else '')+money(val),10.5,'Helvetica-Bold' if y in (207,231,247) else 'Helvetica',color)
 # Fees: show components, recovery, and the remaining cost including the monthly fee.
 c.setFillColor(white);c.setStrokeColor(line);c.setLineWidth(.8)
 c.roundRect(310,792-393,278,118,8,fill=1,stroke=1)
 text(320,289,'FEES',9,'Helvetica-Bold',teal)
 text(320,303,'Total fees',9,'Helvetica-Bold')
 right(580,303,money(a['gross_fees'])+' on '+money(a['gross_sales']),10,'Helvetica-Bold')
 debit_count=sum(v['count'] for v in st['services'] if v['kind']=='Debit')
 credit_count=sum(v['count'] for v in st['services'] if v['kind']=='Credit')
 for y,label,val in [(328,f'Debit ({debit_count})',a['debit_cost']),(341,f'Credit ({credit_count})',a['credit_processing_fees'])]:
  text(320,y,label,8.5);right(580,y,money(val),10.5,'Helvetica-Bold')
 
 text(320,359,f"{data['surcharge_rate_label']} surcharges collected ({a['credit_offset_count']})",8.5,'Helvetica-Bold',red)
 right(580,359,'-'+money(a['surcharge']),10.5,'Helvetica-Bold',red)
 box(316,366,266,24,HexColor('#E5EAFF'))
 text(320,377,'NET PROCESSING COST',9,'Helvetica-Bold')
 text(320,385,'Excluding monthly fee',7.5,color=muted)
 right(580,381,money(a['net_fees']),16,'Helvetica-Bold',HexColor('#3045FF'))
 # Net: rate is the headline; cost and excluded monthly fee remain explicit.
 box(310,402,278,35,HexColor('#3045FF'))
 text(324,422,'NET EFFECTIVE RATE',10,'Helvetica-Bold',white)
 right(574,427,f"{rate_display:.2f}%",24,'Helvetica-Bold',HexColor('#FFFFFF'))
 text(165-stringWidth('Happy with your service & savings?','Helvetica',10)/2,365,'Happy with your service & savings?',10)
 text(165-stringWidth('Leave a Google Review','Helvetica-Bold',11)/2,382,'Leave a Google Review',11,'Helvetica-Bold',teal)
 c.drawImage(str(root/'assets/qr_review.png'),137,792-445,width=56,height=56,mask='auto')
 box(32,452,548,44,HexColor('#168047'));text(46,479,'ESTIMATED ANNUAL SAVINGS',14,'Helvetica-Bold',white);right(565,483,money(annual),26,'Helvetica-Bold',white)
 text(32,522,'VOLUME RECAP',10,'Helvetica-Bold')
 xs=[38,200,260,350,425,496,574]
 headers=['Card type','Avg. ticket','Sales count','Sales total','Refund count','Refunds','Net total']
 box(32,528,548,16,HexColor('#F0F4F6'))
 for x,h in zip(xs,headers):(text if x==38 else right)(x,539,h,7.8,'Helvetica-Bold')
 for i,v in enumerate(st['volumes']):
  y=556+i*12
  vals=[('American Express' if v['brand']=='Amex' else v['brand']),money(cents(v['sales']/v['count'])) if v['count'] else '-' ,str(v['count']),money(v['sales']),str(v['refund_count']),('-' if v['refunds'] else '')+money(v['refunds']),money(v['net'])]
  for x,vv in zip(xs,vals):(text if x==38 else right)(x,y,vv,8.5,color=red if x==496 and v['refunds'] else navy)
 for x,vv in zip(xs,['Totals',money(cents(a['gross_sales']/a['sales_count'])) if a['sales_count'] else '-',str(a['sales_count']),money(a['gross_sales']),str(a['refund_count']),('-' if a['refunds'] else '')+money(a['refunds']),money(a['net_sales'])]):(text if x==38 else right)(x,606,vv,9,'Helvetica-Bold',red if x==496 else navy)
 text(32,627,'SERVICE CHARGES',10,'Helvetica-Bold')
 sx=[38,297,350,425,496,574]
 box(32,633,548,16,HexColor('#F0F4F6'))
 for x,h in zip(sx,['Name','Sales total','Items','Rate','Per item','Fee total']):(text if x==38 else right)(x,644,h,7.8,'Helvetica-Bold')
 order={'Visa':0,'Mastercard':1,'Discover':2,'Amex':3,'':4}
 services=sorted(st['services'],key=lambda v:(order.get(v['brand'],5),0 if v['kind']=='Debit' else 1))
 for i,v in enumerate(services):
  monthly=v['kind']=='Monthly'
  vals=[v['name'].replace(' Discount',''),'-' if v['kind'] in ('Monthly','Other') else money(v['sales']),str(v['count']),rate_text(v['rate']) if not monthly else '-',money(v['per_item']) if v['per_item'] is not None else '-',money(v['fee'])]
  for x,vv in zip(sx,vals):(text if x==38 else right)(x,660+i*10,vv,8 if v['kind']=='Other' else 8.3)
 for x,vv in zip(sx,['Total fees (statement)',money(a['gross_sales']),str(a['sales_count']),'','',money(a['gross_fees'])]):(text if x==38 else right)(x,752,vv,9,'Helvetica-Bold')
 c.translate(0,-55)
 box(32,710,548,64,HexColor('#3045FF'))
 text(48,729,'REFER A BUSINESS',8,'Helvetica-Bold',HexColor('#FFFFFF'))
 text(48,756,'Earn $500',25,'Helvetica-Bold',white)
 c.setStrokeColor(HexColor('#A6AFFF'));c.setLineWidth(.6);c.line(209,792-723,209,792-761)
 text(394-stringWidth('Help another business save on processing.','Helvetica-Bold',10)/2,729,'Help another business save on processing.',10,'Helvetica-Bold',white)
 text(394-stringWidth('Make an introduction. We will take it from there.','Helvetica',8.5)/2,745,'Make an introduction. We will take it from there.',8.5,color=white)
 text(227,763,'David | 855-725-2030 Ext. 807',8.5,color=white)
 right(564,763,'david@carepaymentsgroup.com',8.5,color=white)
 c.linkURL('mailto:david@carepaymentsgroup.com',(433,792-766,564,792-754),relative=0)
 c.save()
 verify_report_address(out,st['address'])
 
 
 return result

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input');ap.add_argument('output');ap.add_argument('--statement',required=True,help='Original statement PDF; its merchant address replaces any cached input address.');args=ap.parse_args()
 source=Path(args.input);data=json.loads(source.read_text());out=Path(args.output)
 # Validation completes before rendering. Render to temporary file and only publish upon success.
 temporary=out.with_suffix('.building.pdf')
 try:
  results=render(data,temporary,args.statement)
  temporary.replace(out)
 except Exception:
  temporary.unlink(missing_ok=True)
  raise
 audit={'kit_version':'1.0','normalized_input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'calculations':results,'reconciliation':data['reconciliation'],'assumptions':{'benchmark':data['comparison_rate'],'annual_includes_monthly':True,'rate_excludes_monthly':True,'refund_policy':'Partial and full-base refunds retain surcharge unless explicit return; full-total returns surcharge. User-confirmed policy.','opportunity':data['opportunity']}}
 out.with_suffix('.audit.json').write_text(json.dumps(audit,default=str,indent=2)+'\n')
 print(out)
