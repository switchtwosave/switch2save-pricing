"""Deterministic calculations on independently reconciled statement/transaction data."""
from decimal import Decimal as D, ROUND_HALF_UP
from datetime import date

def cents(n): return D(n).quantize(D('.01'), rounding=ROUND_HALF_UP)
def require(ok, message):
    if not ok: raise ValueError(message)
def dec(value):
    require(isinstance(value,(str,int)), 'Amounts must be decimal strings, never binary floats')
    n=D(value); require(n.is_finite(),'Nonfinite amount'); return n

def calculate(data):
    require(data['version']=='1.0','Unsupported input version')
    gate=data['reconciliation']
    require(gate['verified'] is True and not gate['unresolved'],'Reconciliation is incomplete: do not issue final report')
    require(bool(gate['evidence']) and bool(gate['sources']), 'Source evidence and hashes required')
    for src in gate['sources']:
        require(len(src['sha256'])==64 and all(c in '0123456789abcdef' for c in src['sha256']), 'Invalid source hash')
    st=dict(data['statement'])
    require(st['merchant'] and st['merchant_id'] and st['address'],'Statement identity required')
    start=date.fromisoformat(st['start']);end=date.fromisoformat(st['end'])
    require(start<=end and (start.year,start.month)==(end.year,end.month),'Single statement month required')
    st['volumes']=[dict(v,**{k:dec(v[k]) for k in ('sales','refunds','net')}) for v in st['volumes']]
    st['services']=[dict(v,**{k:dec(v[k]) if v[k] is not None else None for k in ('sales','fee','rate','per_item')}) for v in st['services']]
    for k in ('fees','released_to_account','deposit_adjustments'):st[k]=dec(st[k])
    require(st['released_source'],'Released-to-account source location required')
    sales=data['retained_sales'];refunds=data['settled_refunds']
    require(len({x['id'] for x in sales+refunds})==len(sales+refunds),'Duplicate ledger IDs')
    for x in sales:
        require(x['status'].upper()=='APPROVED' and x['void'] is False and x['cash'] is False and x['kind'] in ('Credit','Debit'),'Excluded/unknown transaction in retained ledger')
        require(dec(x['amount'])>=0 and dec(x['surcharge'])>=0,'Invalid sale or surcharge')
        require(dec(x['surcharge'])<=dec(x['amount']),'Surcharge exceeds sale')
        require(x['kind']!='Debit' or dec(x['surcharge'])==0,'Debit surcharge exception requires investigation before final report')
    require(len({v['brand'] for v in st['volumes']})==len(st['volumes']),'Duplicate brand summary')
    require(all(x['brand'] in {v['brand'] for v in st['volumes']} for x in sales+refunds),'Unknown ledger brand')
    for v in st['volumes']:
        ss=[x for x in sales if x['brand']==v['brand']];rr=[x for x in refunds if x['brand']==v['brand']]
        require(len(ss)==v['count'] and sum((dec(x['amount']) for x in ss),D(0))==v['sales'],'Sales mismatch: '+v['brand'])
        require(len(rr)==v['refund_count'] and sum((dec(x['amount']) for x in rr),D(0))==v['refunds'],'Refund mismatch: '+v['brand'])
        require(v['sales']-v['refunds']==v['net'],'Statement net mismatch')
    for x in refunds:
        require(x['match_basis'] and dec(x['amount'])>=0 and D(0)<=dec(x['surcharge_returned'])<=dec(x['amount']),'Refund allocation or match evidence missing')
    services=st['services']
    require(all(v['kind'] in ('Credit','Debit','Monthly','Other') for v in services),'Unknown service category')
    for kind in ('Credit','Debit'):
        for brand in {v['brand'] for v in st['volumes']}:
            ss=[x for x in sales if x['kind']==kind and x['brand']==brand]
            sv=[x for x in services if x['kind']==kind and x['brand']==brand]
            require(sum(x['count'] for x in sv)==len(ss) and sum((x['sales'] for x in sv),D(0))==sum((dec(x['amount']) for x in ss),D(0)), 'Fee-assessed volume/count mismatch: '+brand+' '+kind)
    require(sum((v['fee'] for v in services),D(0))==st['fees'],'Service fees do not sum exactly to statement fees')
    G=sum((v['sales'] for v in st['volumes']),D(0));R=sum((v['refunds'] for v in st['volumes']),D(0));N=G-R
    S=sum((dec(x['surcharge']) for x in sales),D(0))-sum((dec(x['surcharge_returned']) for x in refunds),D(0))
    M=sum((v['fee'] for v in services if v['kind']=='Monthly'),D(0));C=st['fees']-M-S;B=N-S
    require(B>0,'Nonpositive sales base requires review; no meaningful standard effective rate')
    require(N-st['fees']+st['deposit_adjustments']==st['released_to_account'],'Released-to-account total does not reconcile')
    cf=sum((v['fee'] for v in services if v['kind']=='Credit'),D(0));df=sum((v['fee'] for v in services if v['kind']=='Debit'),D(0))
    require(cf>0,'Zero/negative credit fees require a separate no-credit-fees presentation')
    recovery=S/cf*100
    tier=next(name for threshold,name in [(D('99.5'),'DIAMOND'),(D(95),'PLATINUM'),(D(90),'GOLD'),(D(75),'SILVER'),(D('-Infinity'),'BRONZE')] if recovery>=threshold)
    cc=[x for x in sales if x['kind']=='Credit'];dc=[x for x in sales if x['kind']=='Debit'];without=[x for x in cc if dec(x['surcharge'])==0]
    a=dict(gross_sales=G,refunds=R,net_sales=N,gross_fees=st['fees'],monthly_service_fee=M,surcharge=S,credit_processing_fees=cf,debit_cost=df,net_fees=C,all_in_net_fees=C+M,credit_offset_count=sum(dec(x['surcharge'])>0 for x in cc),credit_count=len(cc),debit_count=len(dc),sales_count=len(sales),refund_count=len(refunds))
    benchmark=dec(data['comparison_rate']);require(0<=benchmark<1,'Comparison rate must be a decimal fraction')
    annual=cents((B*benchmark-(C+M))*12)
    opp=data['opportunity'];monthly=D(0);eligible_volume=D(0)
    if opp['show']:
        ids=opp['eligible_sale_ids'];require(ids and len(ids)==len(set(ids)),'Opportunity IDs missing/duplicated')
        require(set(ids)<={x['id'] for x in without},'Only documented unsurcharged credit volume eligible')
        for x in without:
            if x['id'] not in ids:continue
            matches=[v for v in services if v['kind']=='Credit' and v['brand']==x['brand']]
            require(len(matches)==1 and matches[0]['rate'] is not None and matches[0]['per_item'] is not None,'Mixed/unknown rates need transaction-level opportunity allocation')
            monthly+=dec(x['amount'])*matches[0]['rate']+matches[0]['per_item'];eligible_volume+=dec(x['amount'])
        require(bool(opp['condition']), 'Opportunity condition required')
        monthly=cents(monthly)
    potential_rate=(C-monthly)/(B-eligible_volume)*100 if B>eligible_volume else None
    return dict(st=st,a=a,base=B,annual=annual,recovery=recovery,recovery_display=recovery.quantize(D(1),rounding=ROUND_HALF_UP),tier=tier,without=without,without_volume=sum((dec(x['amount']) for x in without),D(0)),possible_month=monthly,possible_year=monthly*12,possible_rate=potential_rate,period_label=start.strftime('%B %Y'),rate_display=(C/B*100).quantize(D('.01'),rounding=ROUND_HALF_UP))
