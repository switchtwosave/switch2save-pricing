FICTIONAL TEST DATA ONLY
Choose fictional-epx-statement.pdf and either fictional-valor.csv or fictional-valor.xlsx. All names, addresses, identifiers and activity are synthetic.
Expected: $95.98 net processing, 1.01% effective rate, $1,920.24 estimated annual savings.
